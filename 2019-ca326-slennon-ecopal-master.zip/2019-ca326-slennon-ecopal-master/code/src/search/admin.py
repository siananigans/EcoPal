from django.contrib import admin
from .models import Saved_search


admin.site.register(Saved_search)
