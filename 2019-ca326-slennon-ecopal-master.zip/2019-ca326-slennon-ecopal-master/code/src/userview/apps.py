from django.apps import AppConfig


class UserviewConfig(AppConfig):
    name = 'userview'
