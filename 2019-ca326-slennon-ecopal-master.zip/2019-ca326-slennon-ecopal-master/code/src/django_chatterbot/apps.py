from django.apps import AppConfig


class DjangoChatterbotConfig(AppConfig):
    name = 'django_chatterbot'
