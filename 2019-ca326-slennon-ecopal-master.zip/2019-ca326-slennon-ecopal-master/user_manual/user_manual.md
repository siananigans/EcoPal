# User Manual

## Homepage
When you open EcoPal the first page you will see is the Home page, on this page there is a nav bar which is the bar underneath the heading with links to different pages,information about EcoPal and why we created this app on the right side of the screen and there is a search feature on the left side of the screen.

![alt text](user_manual/homepage.png) 
## Search

This search feature is to find recycling centres near you based on your location. Once you click search the browser will ask you for permission to let EcoPal use your location. The slider bar is so you can pick what distance you would like to search from you.

For example.

Move the slider to 10km and click the search button below.
The browser will ask you to give your permission to let EcoPal use your location. If you wish to click allow, if not click no(The search will not work without your location)

This results from this search will bring you to another page where you can see the recycling centres near you.
If you would like to keep these results you will have to have an account, to do this go to  the nav bar on the page near the top and click Login.

![alt text](user_manual/results.png) 

## Login
If you have an account enter your username and password and continue on.
If you do not have an account you will have to sign Up

![alt text](user_manual/login.png) 
## SignUp
On the SignUp page enter your name email and password to create this account.
Now that you have an account you can save searches by scrolling down to the bottom of the results page and click the save results button. These results are now saved for you to view on your profile.

![alt text](user_manual/signup.png) 
## ChatBot
Back to the homepage you will see a chatbot link in the nav bar. Click this to use our chatbot feature. 
When you are on the chatbot page you will see a text box and a button below saying “Ask”
In this text box you can ask the chatbot a question regarding recycling.

For example:
Type “Hello”
        “Can you recycle batteries”
        “Can you recycle paper”
The chatbot will return with answers and print them above where you typed your question.
To save this answer you can click the save answer button and the answers will be saved to your profile.
![alt text](user_manual/chat.png) 
## Profile Page
Now, to view these saved answers and searches, click the Profile link in the nav bar.
If you are logged in you will see
	-Your name printed
	-Your saved searches
	-Your saved answers

![alt text](user_manual/profile.png) 