---
#  Blog Post EcoPal
#### 02/03/19

***

Going to spend a day refactoring and looking over code today. Trying to tidy up everything and make sure classes, functions and variables are named appropriately. 
