# Blog Post EcoPal
## 
### 11/2/19
 ***
After researching further we have discovered that kivy only gives us a very basic design for the interface so we have decided to incorporate Phonegap into our project. We are going to use jQuery Mobile with phonegap for our frontend.