# Blog Post EcoPal
## 
### 19/2/19
 ***
 We have succesifully gotten our django backend to link with jquery mobile and we will use this to style our html pages.