# Blog Post EcoPal
## 
### 02/2/19
 ***
This week we have been busy doing the user testing, the documentation and the screencast. 
After the initial user testing of five people we decided to change the layout of the UI
slightly to refect the feedback given.

We are nerly finished with the documentation just needs to be given a read through and
check for spelling errors etc.