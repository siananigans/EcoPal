---
#  Blog Post EcoPal
#### 04/03/19

***

Today and tomorrow (05/03/19) we are going to spend cleaning up th UI and makking it more user friendly. We are also going to try recruit users for user testing when the product is finished.