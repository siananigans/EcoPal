# Blog Post EcoPal
## 
### 5/2/19
 ***
We havent looked at that much of our project because of january exams. Now we have begun to create our user interface using kivy.