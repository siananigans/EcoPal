# Blog Post EcoPal
## 
### 21/2/19
 ***
So far we have a login, signup and logout for django. We have a basic chatbot that will respond when you chat to it but it is only training from a small text file.

Currently we are getting the users location using javascript and trying to link the chatbot into django front end so respones will be shown to the users on their screens.

We did try incorporate mySQL as a databse but we decided to use sqlite3 as it is a small and lightweight databse and thats all we need for this app. The database is not our prioirty.