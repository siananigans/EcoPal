# Blog Post EcoPal
## 
### 5/2/19
 ***
Since last week we have been figuring out how and what we need to make our project work. Using python, we have some options for frameworks and one of them we came across is called kivy. This lets us easily create a mobile interface. We think we will use this as our frontend and django as our backend.