# Blog Post EcoPal
### 18/2/19
 ***
We have researched in depth how to use Django between reading the documention along with FAQ's and watching youtube tutorials. D jango uses a server on the local host in port 8000 but phonegap also uses a server so we are not sure what route to take.

