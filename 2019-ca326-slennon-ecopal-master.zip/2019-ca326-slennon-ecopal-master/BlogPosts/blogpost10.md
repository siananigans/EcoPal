# Blog Post EcoPal
### 05/03/19
 ***
We had problems putting our different parts of the projects together today and making sure all was linked. The OpenStreetMaps part of the app is complete just needs cleaning up. Going to spend the rest of the day and part of tomorrow working on user testing. 