##**Functional Spec**

##**EcoPal**  

_Sian Lennon
&
Shannon Mulgrew_


**Table Of Contents**

**1. Introduction**  
1.1 Overview………………………………………………………………………..page 3  
1.2 Business………………………………………………………………………..page 4  
1.3 Glossary………………………………………………………………………...page 4  

**2. General Description**  
2.1 Product/ System requirements……………………………………………....page 4  
2.2 User Characteristics and Objectives………………………………………..page 5  
2.3 Operational Scenarios……………………………………………………......page 6  
2.4 Constraints………………………………………………...……....……….....page 7  

**3. Functional Requirements**  
3.1 Retrieve user location………………………………………………………...page 7  
3.2 Search Street maps……………………………………………………...…...page 8  
3.3 Display results of search………………………………………………...…...page 8  
3.4 Ask ChatBot a question………………………………………………………page 9  

**4. System Architecture**  
4.1 Diagram………………………………………………………………………...page 9  
4.2 App.……………………………………………………………………………..page 10  
4.3 Code..…………………………………………………………………………..page 10  
4.4 ChatBot..….…………………………………………………………………....page 10  
4.5 OpenStreetMaps……………………………………………………………...page 10  
4.6 Database…………………………………………………………………........page 10  

**5. High Level Design**  
5.1 DFD…………………………………………………………………................page 11  
5.2 Object Model…………………………………………………………………..page 12  

**6. Preliminary Schedule**  
6.1 Overview Of Preliminary Schedule………………………………………….page 13  
6.2 GanntChart…………………………………………………………...............page 13  
6.3 Figure…………………………………………………………........................page 14  

**7. Appendices**  
7.1 Research Tools………………………………………………………….........page 14  
7.2 References…………………………………………………………...............page 14  







#**1.Introduction**

##**1.1 Overview**

EcoPal will be a mobile app with the main aim of providing users with a reliable, viable and easy way of recycling while also providing answers to any recycling related queries they may have.

It is a well known fact that Ireland's landfills are overflowing and if nothing is done to help this they will be full to the brim. Recycling is a very useful and important concept and an effort must be made to make it a more common practice.Our hope is that EcoPal will be a go-to app for all queries regarding recycling,global warming and climate change.



EcoPal will have several features that will ease the process of recycling waste:

- One feature of our app will be a location based search that will take a user's location and provide places to recycle depending on the waste the user has input.

- Similarly, we plan to have a service that will allow users to find Eco-friendly and vegetarian/vegan restaurants near them based off their location.

- For the last part of the app, we will have an interactive ChatBot that will allow users to ask it questions regarding climate change and recycling to which the ChatBot will reply appropriately.

At the moment, there is no real emphasis on recycling centers and places a person can go to recycle waste. There is of course a recycling bin that can be collected fortnightly from a person's residence. Of course this only covers a small part of recyclable waste such as plastic/paper and a service is required for other recycling too.



##**1.2 Business Context**

Our app currently does not have any sponsors and we have no plan to look for any sponsors. The goal of this app is not to gain profit but to encourage people to help our environment. Although in the past the UN have given grants to people who have come up with Environment Friendly ideas that they would like to fund in order to implement.

##**1.3 Glossary**

**HTML-** Hyper text Markup Language:

Html is the code that is used to structure a web page and its content.

**ChatBot-** An interactive computer program that simulates human conversation with regards to the environment in this case.

#**2. General Description**

##**2.1 Product / System Functions**

EcoPal has two main purposes, the first being a search for places to recycle waste and the second being the interactive chatbot that answers queries from the user. In order to achieve these two functions of the app the below functions must be done by the app:

- Get user location.
- Search street maps.
- Display list of places.
- Filter results.
- Retrieve information from the internet about the places.
- Chatbot takes and understands user input using natural language processing.
- Chatbot replies with appropriate answer derived fro-m machine learning and or database querying.

##**2.2 User Characteristics and Objectives**

We plan on providing an easy to use app for users. The app should have a simplistic interface with simple graphics that users can understand and interact with. This is to emphasise how easy recycling in general can be. An easy to use app will be more desirable than a complex app which would just frustrate users and could lead to less interest in using it.



The app will require the users location in order to provide a list of nearby places. In order to get the location of the user they must be notified and allow the app to access location services on their device. The user wouldn&#39;t want the app to know their location without their permission.

The app must be as reliable as possible with its results from the search, the app must present these results in an easy to understand way as we aren&#39;t expecting any technical knowledge from our users and want the information to be easily read and understood by whoever is using the app.

The user would benefit from links to websites of the different recycling options/restaurants that the search results give back. This is so they don&#39;t have to separately search for information on these places themselves.

In order to weed out any unwanted places to recycle, a filter system will be implemented. This will allow the user to get rid of any places they don&#39;t want to go. For example they can set their search radius to a lower setting to eliminate the places further away.

The ChatBot element of the app should be as easy to use as the rest of the app, a user types in some input the chatbot then returns and answer to the user without a long delay.



##**2.3 Operational Scenarios**

**Scenario 1:**

The user is presented with an interface with a search bar. They press the search bar and type in &#39;Clothes&#39;. Next, a list would appear of all the places near the user that clothes can be recycled. The list is returned in order of places closest to the user to the furthest from them. User changes the filter so their radius is 30km and below. User scrolls through the results until he/she finds a place that suits their needs.

**Scenario 2:**

User has a bunch of Polyethylene plastic that they don&#39;t know if they can throw in the recycling bin. They open the app and on the home screen the chat-bot is located. They type in the question &#39;can Polyethylene plastic be put in the blue recycling bin?&#39;. The chat-bot returns an answer &#39;Yes&#39; to the interface.

**Scenario 3:**

User opens app in order to find a coffee shop near them that uses compostable cups as they have forgotten their reusable cup. User clicks into Cafe section which looks after eco friendly cafes and clicks near me, the app will return a list of coffee shops near them that provide this service.

**Scenario 4:**

The user asks the ChatBot what are the main causes of global warming, the ChatBot will reply with an appropriate answer.

**Scenario 5:**

The user requests to find local vegetarian/vegan Restaurants near them, the user has not given permission to the app to allow it access to its location. Therefore the app informs the user to change the setting in their phone to give access in order to carry out the task.

##**2.4 Constraints**

There aren&#39;t too many constraints on this project because of the nature of it. However a few have arisen since starting including:

- **Location permissions-** User will need to allow permissions.
- **Time constraints-** Will we get everything completed in the given time frame.
- **Ethical constraints-** Details must be retrieved from the website of the recycling places listed. This can be difficult to do because of ethical duty of not scraping websites.

#**3. Functional Requirements**

##**3.1 Retrieve users location**

<u>Description:</u>

As the main feature of the app will be to search for places near the user that will cater to their recycling needs, the system must find first find the users location.

<u>Criticality:</u>

This requirement is very essential as the user will want a list of nearby places they can visit and if a non-location search is done it is essentially pointless.

<u>Technical issues:</u>

Location services are needed to to complete this part of the project. The HTML Geolocation API is used to get the geographical position of a user, however the user will need to approve the permissions and without the permission the search will not work.

<u>Dependency with other requirements:</u>

None that we know of.

##**3.2 Search street maps**

<u>Description:</u>

Once the location is found the app must return a list of places to the user, these must first be found on the open street maps available.

<u>Criticality:</u>

This requirement is essential as without it no places could be found and returned to the user making the app fairly redundant.

<u>Technical issues:</u>

Open street maps are not always complete and there could possibly be places missing that should be on there. The search will miss these.

<u>Dependency with other requirements:</u>

The search needs to know the users location before it begins searching for places within that region. This requirement also requires the open street map resource in order to work.

##**3.3 Display results of the search**

<u>Description:</u>

The system must allow the users to see the results of the search. The interface must display the list in a certain order and must show the distance from the user.

<u>Criticality:</u>

This requirement is really needed at its most basic level because a list of places must be seen by the user, however extra information is not strictly essential.

<u>Technical issues:</u>

None.

<u>Dependency with other requirements:</u>

The results will depend on the search of the places nearby to recycle. It will rely on the search to retrieve the places for this requirement to display.

##**3.4 Ask ChatBot a question**

<u>Description:</u>

Asking the ChatBot a question regarding global warming, recycling etc is one of the main features of our app. A user asks the ChatBot 'What is the main cause of global warming?'

<u>Criticality:</u>

The ChatBot must produce an appropriate answer to this question from machine learning and querying a database using Sql.

<u>Technical issues:</u>

The ChatBot may interpret information incorrectly and return an answer that does not help the user.

<u>Dependency with other requirements:</u>

The ChatBot is dependent on the database it is learning from.

#**4. System Architecture**

##**4.1 Diagram**

![error](func_Spec.png)

This diagram shows a high level overview of the system as a whole. The OpenStreetMaps and the database components are third party components that will be incorporated in the system.

##**4.2 App**

The app component of the system architecture is what the user interacts with, the front end of the app. It will just be there so the user can interact with other components.

##**4.3 Code**

The &#39;code&#39; part of the project will work in two ways. It takes html from the app and uses it to get a command, it then uses the command to interact with the OpenStreetMaps and the ChatBot. Probably the most complex part of the architecture.

##**4.4 ChatBot**

The ChatBot component is a component we will be making to interact with users. The bot, like the code will be sent a html with users input on it, it processes the input and uses the third party database to retrieve the answer and convert that to html and send it to the app for the user to see.

##**4.5 OpenStreetMaps**

OpenStreetMaps is a third party component we will be using. It is an  open source, community driven and free service that allows people to see and interact with a map of the world. This will be used to find locations of places users can recycle/ eat organic.

##**4.6 Database**

The other third party component we will be using is the recycling based database. The chatbot will use this to find answers to queries by querying the database.

#**5. High-Level Design**

This section should set out the high-level design of the system. It should include one or more system models showing the relationship between system components and the systems and its environment. These might be object-models, DFD, etc.







##**5.1 DFD**

![error](dataFlowFuncSpec.png)


This DFD describes the flow of data around the app. The user inputs data into the search which uses OpenStreetMaps data to return data back to user. This can only be done when location is requested off the user and the user gives the location services their permission, which is modelled above.

Another flow of data happens when the user interacts with the chatbot and feeds it an input, the chatbot processes this data an uses the database to return data to the user.

##**5.2 Object Model**
![error](func_Spec.png)

The EcoPal object model above models the way in which the user interacts with the ChatBot queries to find the answers to the questions.

##**6.1 Overview Of Preliminary Schedule**

The schedule below was created by teamGantt **6.2** shows a list of tasks to be completed and the amount of time spent on each task can be compared on the left.

The figure **6.3** displays the start date of each task and the duration of each task.





##**6.2 GanntChart**
![error] (ganttt.png)

##**6.3 Figure**
![error] (Ganttyy.png)

#**7. Appendices**

##**7.1 Research Tools**

-  [https://www.w3schools.com](https://www.w3schools.com)
- [https://www.mysql.com](https://www.mysql.com)
- [https://azure.microsoft.com/en-us](https://azure.microsoft.com/en-us)

##**7.2 References**

- [http://www.epa.ie/irelandsenvironment/waste](http://www.epa.ie/irelandsenvironment/waste)

