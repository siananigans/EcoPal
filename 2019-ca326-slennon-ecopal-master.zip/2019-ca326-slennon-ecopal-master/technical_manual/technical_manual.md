 ***0. Table of contents***  

   **1.Introduction**
- 1.1 Overview
- 1.2 Glossary
- 1.3 Changes we made


<br/>**2.System Architecture**

-  2.1 System Overview
-  2.2 System Fronted
-  2.3 System Backend

<br/>**3.High Level Design**
- 3.1 High Level Design Diagram
- 3.2 Data Flow Diagram
  

<br/>**4.Challenges and Resolutions**
- 4.1 Challenges and Resolutions
   

<br/>**5.Installation Guide**
- 5.1 Installing Dependencies
- 5.2 Installing Project

<br/>

**1.1 Overview**

EcoPal is a web application with the aim to assist and encourage day to day users to be more eco-friendly and help reduce unnecessary waste going into our landfills. The services provided by this app are there to make it easy for users to find local recycling centres and to ask questions regarding recycling. We hope that  EcoPal will help users learn about recycling and assist them in finding recycling centres.

EcoPal has two main features, the first of which is  to display all the local places a person can recycle based off the users location. This part of the app works with the users GPS location and a distance range set by the user to retrieve a list of places this person can recycle within their set range. The list also displays the address of the place, how far away each place is and what they can recycle there. This information is displayed with all of these details in order to help and encourage users to access these recycling centres.

The second component of EcoPal is the recycling chatbot made for answering any recycling based queries a user may have. The Chatbot uses data provided and also a learning aspect to return appropriate answers to the users. The (usually ) short answer is displayed with the hope that it&#39;s not as daunting as a large paragraph filled with irrelevant information and the user gets the answer to their question.

The application also has an option for signing up to EcoPal to create an account.This account side to the app allows for a personal feel to the application, allowing each user to save their search results for recycling centres and favorite their answers from the chatbot. The user can then login to their profile page and view their name, email and their saved searches and saved answers if they have any.




**1.2  Glossary**

**Html** - _Hypertext Markup Language_

**Function** - _set of operations on data._

**HTTP** - _Hypertext Transfer Protocol designed to enable communications between clients and servers_

**HTTP GET METHOD** - _GET Request is to request data from source_

**HTTP POST METHOD** - _POST method is to send data to a server to create/update a resource_

**Front-End** - _Client side(the part of the project the user sees)_

**Backend** - _Part of the system the client/ user does not see_

**Api** -_Application Programming Interface_

**Chatbot** -_Computer Program which conducts a conversation_

**Django** -_High level web framework_

**Database** - _Data held in a computer that&#39;s accessible_

**SQLite** - _Database used for Django_

**Ajax** - _Asynchronous Javascript and XML.__Techniques used to send data to and from Backend._

**JSON** - _Javascript Object Notation is a lightweight way of sending and receiving data._

**Virtual Environment** - _a tool to help keep dependencies required by different projects separate._

**Bbox-** _An open street maps search area._

**CD -** _Change Directory (Command line tool to change folders in windows, mac and linux)_

**SUPER-USER-** _A user with admin rights for managing Django databases, much like sudo user on Linux machines._

**GPS -** _Global Positioning System (System for location used worldwide)_

**1.3 Changes we made**

There were a number of changes made from what was proposed for this project in the functional spec and what the application is today.

The functional spec proposed an app that would query open street maps for a list of recycling places but also results regarding restaurants, and cafes that did compostable cups and organic food. Only the recycling places feature was added because the open street maps had limited information on cafes and restaurants regarding recycling. We thought it would be more important instead to focus on the places to recycle and make those results more useful, adding more information on them than what was proposed in the functional spec including distance away and what can be recycled in that place.

Another change we made was adding a login/logout and signup component to our app. This came about when doing research on apps. We wanted to create a personal element to the app and also allow the user to save their searches based off of user id.

The web app you see today was originally meant to be a mobile app but after research we decided to implement a web app as it fit well with our idea. We also made the UI very mobile friendly so mobile users can use it with ease.



**2.1 System Overview**



The system is split between the python backend, a SQLite database and the javascript/html frontend. The backend uses the framework django and the frontend implements jQuery and jQuery mobile.

Django follows a Model-View-Controller(MVC) architecture system. This means Django is split into three main sections.

1. Models
2. Views
3. Controller

The models are the data structure behind the app, aka the database. The views which is what is displayed in the browser so in your case the JavaScript frontend. Then there is the controller, which links the two together.

The two interact by using ajax calls from the frontend to the backend that send post and get requests. The ajax calls reach the backend files via endpoint urls set by us in your django urls.py. The controller would then be called which would then do a certain action such as manipulate data or get data from the model. There are a number of html forms within our app that take data which is sent to the backend using javascript and processed by the python backend files. This database is linked with our django backend and can only be accessed via the backend or manually using the django built in admin page used to manage the database by the super-user.

A Django project architecture consists of a core file and at least one app and templates for displaying the data. We have the core EcoPal files and then a search app, chatbot app, accounts app and of course our templates for viewing.- Fig 1.1

**2.2 System Frontend**

The actual user interface is fairly basic as more emphasis was put on the functionality of the architecture.


![alt text](technical_manual/Untitled.png)
Fig 1.1



The EcoPal home page is the main page for searching for local recycling places. The user inputs their radius distance they want to search by using the slider. This distance is combined with the users GPS location which is retrieved using javascript geolocation. Once both data is retrieved and verified, it is sent via in JSON format as a ajax post request to a url endpoint where the backend picks it up, processes it a returns a HTTP result. This result is processed by javascript and displayed on the results page. On the results page a save button is located at the bottom of the screen to let the user save their search this is done via ajax also.



The EcoPal homepage has a button linked to the chatbot homepage. On this page the user inputs their question into the text box. The question is sent in JSON format via an ajax post request to the backend. The backend functions process this data and return a HTTP response. This answer is displayed above the text box on the same page. Along with the answers being displayed another button is displayed underneath giving the user the option to save the answer. This is implemented via other ajax call.

The linking system in this project is implemented via Url patterns which django looks for to redirect pages. The url pattern tells the system what view to look at and in the view it will return the html page. For example

&quot;href=&quot;{% url &quot;home&quot; %}&quot; - This is the link using django&#39;s url naming system within HTML

 &#39;home&#39; above is linked with the url pattern below because the name=&#39;home&#39; matches.

&quot;path(&#39;homepage/&#39;,views.dipslayHome , name=home)&quot;

This path send django to views.displayHome which is a function in the python file views called displayHome()

In this function the file path to home.html is returned.

**2.3 System Backend**

When data is sent by the ajax calls from the frontend, the url it is sent to is specified in our EcoPal urls.py file and sent to a specific function within our views.py files to be processed and returned to our frontend.

An example of this architecture is the search app within EcoPal. The longitude and latitude of the user is sent to the url specified by the ajax called. The django file urls.py uses the django method of path, the provided a path based on that url. For recycling centers search, ajax calls search/, our backend then sends this to function Find\_Coords() within views.py within the search app. This function takes the data and from there sends it to another function Make\_box() to make a range box for querying Open Street Maps, this then gets sent to another function search() to query the open street maps using the overpassed api. Json data is returned from this query and this is sent to the next function sort(). This function is for extracting the information from the Open Street Maps api result we want to display on our webpage. This function uses a function FindDist() to find the distance between user and each place received based on the two locations. The last function called is nodeLocation() which uses the module Geopy to retrieve an address for each place given by Open Street Maps. Once the data is processed by these functions the data is returned to the ajax called and the ajax is successful.

The ChatBot app within EcoPal also demonstrates a similar architecture. From the home page a button is click which send the user to the chatbot homepage. This click triggers a url link which finds the html page based on the name you provided in the urls. When a user inputs a question the javascript function getAnswer() is called in the script tags. The function gets the value the user has inputted and stores in a variable which is then sent via an Ajax post to the backend. This call is sent to the function getResponse. In this function it can either take a given text file with concrete answer and pick an appropriate response or it can use the get

\_response function in chatterbot library to choose an answer. This answer is then returned to the ajax success function.

When we created this application, we knew we wanted to implement an accounts app into django to allow users to save search results in our database. For saving the data for from the chatbot or from the search, the data is sent to the view where it is put into the database based off of their user profile as a foreign key, this makes it so that no other user can access their data but them. When accessing the data, their user profile and the primary key of the entry number is used to retrieve the data from the model.













**3.1 High Level Design Diagram**

![alt text](technical_manual/highleveldesign__1_.png)

Stage 1: Login page is displayed for users to login to EcoPal. If user does not have an account they can sign up and then login.

Stage 2: After user logs in they can view the Home Page

Stage 3: From the home page user can use the search feature.

Stage 4: From the home page user can also access the results from the search feature, they can use the ChatBot and view their profile

Stage 5: From the homepage, results page or chatbot page users can click into their profile to view saved answers and searches.



**3.2 Data Flow Diagram**

![alt text](technical_manual/dfd2.png)

Above is the diagram of the data flow within our application.

Firstly a user tries to login via the login page, the username and password they provide is sent and checked in the users database. If the user is there and authenticated they are redirected to the home page if not they are asked to sign up on the signup page.

The signup page takes a users username, email and password. When the user clicks submit the details are added to the user database and they login once again and get redirected to the homepage.

At the homepage if the user uses the search feature and saves the results the data is sent to the saveSearch database. If the user wishes to save an answer the data is added to the saveAnswer database.

On the view Profile page which can be access from the hompage, the users name, saved searches and saved answers comes up.

This page gets the data from three models, the users database, the save searches database and the saved answers database .



**4.1 Challenges and Resolutions**



Before we began this project we had never used a framework when developing software. We chose django because we were most comfortable writing in python and had heard django was a great framework for building api&#39;s that implement the REST framework. Django was very daunting to work with to begin with and did overwhelm us a bit. We basically threw ourselves in the deep end with this framework. After a lot of videos and tutorials on the subject, we dived into the development of our app and little by little learned how django works and its architecture.

Linking the backend and frontend using requests such as post and get was a new task for us. To begin with it was a little difficult because we weren&#39;t sure what we were doing. However after a lot of research and tutorials we managed to get one ajax call working and the rest followed suit soon after. The use of apis within this project really helped us understand how system architecture should work.

The Ajax was difficult to get working for some elements of the project. If you wanted to display your results on a separate page the ajax success function worked perfectly because the data was sent with the url. On the other hand if you wanted to print the returned data on the same page it became difficult because the success function would run but the data inside would be undefined because it didn&#39;t have time to get the data from the backend because Ajax is after all asynchronous. To resolve this issue we used to function .when().then(). This basically waits for the ajax to return a value before entering a success or error function. This fixes our problem of our data being undefined.

The models were at first hard to work with. There is a lot of information available for creating them however. The thing that proved difficult mostly was using instances of the user model within our models as foreign keys to allow the user to save a search to their profile only. This was an important lesson however and once we found the built in user methods for accessing user data we were well on our way to creating the model.

Open Street Maps data can be hard to wrap your head around. Querying the overpass api endpoint was a very tedious task. Initially we were going to use the google maps api but thought open street maps would be better because of how open source it is and how much data is poured into its database regularly. However open street maps is a lot harder to query than the google maps api. For open street maps a &#39;bbox&#39; must be created to retrieve data from within the search area you want. This had to be done by us using math formulae. Also open street maps doesn&#39;t have any options for finding distance between places or even finding location of results. This all had to be done separately by us and took some time. We hadn&#39;t planned on implementing some of the features before in our functional spec but we ran into difficulty with getting data on restaurants and cafes like we said we would in the functional spec. We then decided to focus solely on recycling and improve on the functionality of that as it seemed more important and inline with our app.



Implementing and training the chatbot was difficult to understand at first due to the limited information available regarding the library we used which is Chatterbot. The integration of chatterbot with django was tedious as it had to be in a certain format with keywords in order for it to run smoothly. The chatbot primarily reads from a text file with faqs regarding climate change and recycling, this is to insure best accuracy when answers questions from users as chatterbot doesn&#39;t have a built in environment library to train from. Getting the chatbot to work with django took time but we successfully implemented it

Kivy, phonegap - At the beginning of the development of our app we wanted to create a mobile app built with two servers. One backend django server and one front end PhoneGap server. This proved very difficult. We began by writing the front end with the mobile framework kivy that works with python. This framework was difficult to work with and it had very little information regarding how to use it etc. It didn&#39;t offer as much variety in styling as we had hoped and we soon realised that we needed to take another direction.  After a week or so we had to remodel our architecture to better reflect what we wanted for the app and what was achievable. That&#39;s when we decided to use django as a sole server for backend and front end and to implement jQuery mobile.This is to give it a mobile app feel for mobile users that use it on their phone browser while also looking good on a normal monitor screen. This allowed us to include other device user to use EcoPal as well.

Another challenge we had was that we were very new to writing in Javacript, it took some time, tutorials and practice to understand it fully so we could use it to its best potential.











**5.1 Installing Packages**

To begin to use this application you will need to install some dependencies.

1. Firstly you should have the latest version of python (python 2.7 or later) installed. If you do not please follow instructions on this link to do so [python.org/downloads/](http://www.python.org/downloads/)
2. To download django you simply - **pip install django**
3. When using django a good thing to use is a virtual environment, the virtual environment package we used was Virtualenv. To install this simply - **pip install virtualenv**
4. Activate your virtualenv and then install these packages.
5. We use the python library ChatterBot for the chatbot, to install _-_ **pip install chatterbot, chatterbot-corpus**
6. We used the Open street maps API called overpy. To use this please install - **pip install overpy, geopy**
7. To allow you to send HTTP Requests please install - ** pip install requests**

**5.2 Installing EcoPal**

1. To download this project simply download and extract files from this repo:

[https://gitlab.computing.dcu.ie/lennos34/2019-ca326-slennon-ecopal](https://gitlab.computing.dcu.ie/lennos34/2019-ca326-slennon-ecopal)

1. Once downloaded cd into folder where a python file manage.py is location and run the django command **python manage.py runserver**
2. Once this runs successfully in the terminal follow the link it shows (_127.0.0.1:8000)_ therwise known as your localhost on port 8000.